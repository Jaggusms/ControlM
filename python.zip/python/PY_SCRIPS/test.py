try:
    a=[0,2].index(1)
except:
    a=-1
print(a)